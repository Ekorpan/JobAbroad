# Starter for Gulp Project
To initialize project: npm i

To add package: npm install [package_name] --save / npm install [package_name] --save-dev

## Gulp tasks
gulp watch / gulp - run watcher for html/scss/js files

gulp build - build minified project
