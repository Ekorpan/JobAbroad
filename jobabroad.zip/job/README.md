# Starter for SCSS
sass --watch scss/global.scss:css/styles.min.css --style compressed
