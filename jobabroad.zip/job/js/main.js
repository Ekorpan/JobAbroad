'use strict';

(function($){
	$(document).ready(function() {


	});
	})(jQuery);

function initMap() {
	  	var mapCenter = {lat: 50.470149, lng: 30.508248};
	  	var mapDiv = document.getElementById('map');
	  	mapsTypeId: google.maps.MapTypeId.ROADMAP

	  	var map = new google.maps.Map(document.getElementById('map'), {
	  		zoom: 15,
	  		center: mapCenter,
	  		disableDefaultUI: true,
	  		styles: [
	  		{
	  			"elementType": "geometry.fill",
	  			"stylers": [
	  			{
	  				"color": "#c8c4da"
	  			},
	  			{
	  				"visibility": "on"
	  			},
	  			{
	  				"weight": 1.5
	  			}
	  			]
	  		}
	  		]
	  	});

	  	var marker = new google.maps.Marker({
	    	position: new google.maps.LatLng(50.470149, 30.508248),
	    	map: map,
	    	icon: "images/favicon.png",
	  	});
	  }

	  window.onload = initMap;